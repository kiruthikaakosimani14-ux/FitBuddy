# FitBuddy

Complete FastAPI + Jinja2 + SQLite + Gemini implementation of the supplied FitBuddy documentation. The original document specified Gemini 1.5 Pro/Flash; this implementation uses the current Google GenAI Python SDK and configurable model IDs. Defaults are Gemini 2.5 Pro for structured workout planning and Gemini 2.5 Flash for fast nutrition tips. If no API key is configured, a deterministic demo mode keeps the application runnable and testable.

## VS Code setup
1. Install Python 3.11+ and VS Code.
2. Open this folder in VS Code.
3. Create a virtual environment: `python -m venv .venv`
4. Windows: `.venv\\Scripts\\activate`; macOS/Linux: `source .venv/bin/activate`
5. Install: `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`.
7. Put your Gemini API key in `GEMINI_API_KEY` for live AI. Leave it blank to use demo mode.
8. Start: `uvicorn app.main:app --reload`
9. Open `http://127.0.0.1:8000` and API docs at `http://127.0.0.1:8000/docs`.

## Test
Run `pytest -q`.

## Main routes
- `/` user form
- `/generate-workout` HTML generation
- `/submit-feedback` HTML feedback update
- `/view-all-users` admin dashboard
- `/api/generate-workout` JSON API
- `/api/submit-feedback` JSON feedback API
- `/api/users` JSON admin list
- `/health` and `/api/health` health checks

## Admin
Set `ADMIN_TOKEN` in `.env` to protect the admin pages/API. Then use `/view-all-users?token=YOUR_TOKEN` for local browser access, or send `X-Admin-Token` for API access.

## Safety
The app generates general fitness/nutrition information, not medical advice. Users with injuries, medical conditions, pregnancy, or other health concerns should consult a qualified professional.
