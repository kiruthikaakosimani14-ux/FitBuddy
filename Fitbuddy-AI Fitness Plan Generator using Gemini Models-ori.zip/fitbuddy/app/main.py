from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .database import init_db
from .config import get_settings
from .routes import router
@asynccontextmanager
async def lifespan(app): init_db(); yield
s=get_settings();app=FastAPI(title=s.app_name,version='1.0.0',lifespan=lifespan);app.mount('/static',StaticFiles(directory='static'),name='static');app.include_router(router)
@app.get('/health')
def health():return {'status':'ok','service':s.app_name}
