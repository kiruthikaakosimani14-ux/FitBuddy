from datetime import datetime
from sqlalchemy import create_engine,select,Integer,String,Float,Text,DateTime,ForeignKey
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,relationship,sessionmaker,Session
from .config import get_settings
s=get_settings(); engine=create_engine(s.database_url,connect_args={'check_same_thread':False} if s.database_url.startswith('sqlite') else {})
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
class Base(DeclarativeBase): pass
class User(Base):
 __tablename__='users'; id:Mapped[int]=mapped_column(Integer,primary_key=True); user_id:Mapped[str]=mapped_column(String(80),unique=True,index=True); username:Mapped[str]=mapped_column(String(120)); age:Mapped[int]=mapped_column(Integer); weight:Mapped[float]=mapped_column(Float); goal:Mapped[str]=mapped_column(String(200)); intensity:Mapped[str]=mapped_column(String(20)); created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow); plan:Mapped['Plan|None']=relationship(back_populates='user',cascade='all, delete-orphan',uselist=False)
class Plan(Base):
 __tablename__='plans'; id:Mapped[int]=mapped_column(Integer,primary_key=True); user_id:Mapped[int]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),unique=True); original_plan:Mapped[str]=mapped_column(Text); nutrition_tip:Mapped[str]=mapped_column(Text); updated_plan:Mapped[str|None]=mapped_column(Text,nullable=True); feedback:Mapped[str|None]=mapped_column(Text,nullable=True); updated_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True); user:Mapped[User]=relationship(back_populates='plan')
def init_db(): Base.metadata.create_all(bind=engine)
def get_db():
 db=SessionLocal()
 try: yield db
 finally: db.close()
def get_user(db:Session,user_id:str): return db.scalar(select(User).where(User.user_id==user_id))
def save_user(db:Session,**d):
 u=get_user(db,d['user_id'])
 if not u: u=User(**d); db.add(u)
 else:
  for k,v in d.items(): setattr(u,k,v)
 db.commit(); db.refresh(u); return u
def save_plan(db,u,original_plan,nutrition_tip):
 p=u.plan
 if not p: p=Plan(user_id=u.id,original_plan=original_plan,nutrition_tip=nutrition_tip); db.add(p)
 else: p.original_plan=original_plan;p.nutrition_tip=nutrition_tip;p.updated_plan=None;p.feedback=None;p.updated_at=None
 db.commit();db.refresh(p);return p
def update_plan(db,u,updated_plan,feedback):
 u.plan.updated_plan=updated_plan;u.plan.feedback=feedback;u.plan.updated_at=datetime.utcnow();db.commit();db.refresh(u.plan);return u.plan
def get_all_users(db): return list(db.scalars(select(User).order_by(User.created_at.desc())).all())
def delete_user(db,user_id):
 u=get_user(db,user_id)
 if not u:return False
 db.delete(u);db.commit();return True
