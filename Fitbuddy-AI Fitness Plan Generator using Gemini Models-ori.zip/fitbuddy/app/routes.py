from fastapi import APIRouter,Depends,Form,HTTPException,Request
from fastapi.responses import HTMLResponse,JSONResponse,RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from .config import get_settings
from .database import *
from .schemas import UserInput,FeedbackRequest,GenerateResponse
from .services.ai_service import GeminiService
router=APIRouter(); templates=Jinja2Templates(directory='templates'); ai=GeminiService()
def admin_ok(r):
 t=get_settings().admin_token; return not t or (r.headers.get('X-Admin-Token') or r.query_params.get('token'))==t
@router.get('/',response_class=HTMLResponse)
def home(request:Request): return templates.TemplateResponse(request=request,name='index.html',context={'app_name':get_settings().app_name})
@router.post('/generate-workout',response_class=HTMLResponse)
def generate(request:Request,user_id:str=Form(...),username:str=Form(...),age:int=Form(...),weight:float=Form(...),goal:str=Form(...),intensity:str=Form(...),db:Session=Depends(get_db)):
 try:
  d=UserInput(user_id=user_id,username=username,age=age,weight=weight,goal=goal,intensity=intensity);u=save_user(db,**d.model_dump());p=ai.generate_workout(**d.model_dump());tip=ai.generate_nutrition_tip(d.goal,d.intensity);save_plan(db,u,p,tip);return templates.TemplateResponse(request=request,name='result.html',context={'user':u,'plan':p,'nutrition_tip':tip,'updated_plan':None,'feedback':None,'ai_live':ai.live})
 except Exception as e:return templates.TemplateResponse(request=request,name='error.html',context={'message':str(e)},status_code=400)
@router.post('/submit-feedback',response_class=HTMLResponse)
def feedback(request:Request,user_id:str=Form(...),feedback:str=Form(...),db:Session=Depends(get_db)):
 d=FeedbackRequest(user_id=user_id,feedback=feedback);u=get_user(db,d.user_id)
 if not u or not u.plan:raise HTTPException(404,'User or workout plan not found')
 try:
  revised=ai.update_workout(u.plan.original_plan,d.feedback,u.goal,u.intensity);update_plan(db,u,revised,d.feedback);return templates.TemplateResponse(request=request,name='result.html',context={'user':u,'plan':u.plan.original_plan,'nutrition_tip':u.plan.nutrition_tip,'updated_plan':revised,'feedback':d.feedback,'ai_live':ai.live})
 except Exception as e:return templates.TemplateResponse(request=request,name='error.html',context={'message':str(e)},status_code=400)
@router.get('/view-all-users',response_class=HTMLResponse)
def users(request:Request,db:Session=Depends(get_db)):
 if not admin_ok(request):raise HTTPException(403,'Invalid admin token')
 return templates.TemplateResponse(request=request,name='all_users.html',context={'users':get_all_users(db),'admin_token':request.query_params.get('token')})
@router.post('/admin/delete/{user_id}')
def delete(request:Request,user_id:str,db:Session=Depends(get_db)):
 if not admin_ok(request):raise HTTPException(403,'Invalid admin token')
 delete_user(db,user_id);t=request.query_params.get('token');return RedirectResponse('/view-all-users'+(f'?token={t}' if t else ''),303)
@router.get('/api/health')
def api_health():return {'status':'ok','ai_mode':'gemini' if ai.live else 'demo'}
@router.post('/api/generate-workout',response_model=GenerateResponse)
def api_generate(d:UserInput,db:Session=Depends(get_db)):
 u=save_user(db,**d.model_dump());p=ai.generate_workout(**d.model_dump());tip=ai.generate_nutrition_tip(d.goal,d.intensity);save_plan(db,u,p,tip);return GenerateResponse(user_id=u.user_id,username=u.username,goal=u.goal,intensity=u.intensity,workout_plan=p,nutrition_tip=tip)
@router.post('/api/submit-feedback')
def api_feedback(d:FeedbackRequest,db:Session=Depends(get_db)):
 u=get_user(db,d.user_id)
 if not u or not u.plan:raise HTTPException(404,'User or workout plan not found')
 p=ai.update_workout(u.plan.original_plan,d.feedback,u.goal,u.intensity);update_plan(db,u,p,d.feedback);return {'user_id':u.user_id,'updated_plan':p,'feedback':d.feedback}
@router.get('/api/users')
def api_users(request:Request,db:Session=Depends(get_db)):
 if not admin_ok(request):raise HTTPException(403,'Invalid admin token')
 return JSONResponse([{'user_id':u.user_id,'username':u.username,'age':u.age,'weight':u.weight,'goal':u.goal,'intensity':u.intensity,'original_plan':u.plan.original_plan if u.plan else None,'updated_plan':u.plan.updated_plan if u.plan else None} for u in get_all_users(db)])
