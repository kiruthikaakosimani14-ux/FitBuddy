import json
from google import genai
from google.genai import types
from pydantic import BaseModel,ValidationError
from ..config import get_settings
class Exercise(BaseModel): name:str; sets_or_duration:str; rest:str; notes:str=''
class DayPlan(BaseModel): day:str; focus:str; warmup:str; exercises:list[Exercise]; cooldown:str
class WorkoutPlan(BaseModel): title:str; overview:str; days:list[DayPlan]
class NutritionTip(BaseModel): tip:str; why_it_helps:str

def demo_workout(goal,intensity,name):
 vol={'low':'2 sets','medium':'3 sets','high':'3–4 sets'}[intensity]; days=[('Day 1','Full body','Squats; Incline push-ups; Glute bridges'),('Day 2','Cardio + core','Brisk walk; Dead bug; Plank'),('Day 3','Upper body','Rows; Shoulder press; Wall push-ups'),('Day 4','Active recovery','Easy walk; Mobility; Stretching'),('Day 5','Lower body','Lunges; Hip hinge; Calf raises'),('Day 6','Conditioning','Step-ups; Marching intervals; Bird dog'),('Day 7','Recovery','Easy walk; Mobility; Breathing')]
 out=[f'FITBUDDY 7-DAY PLAN FOR {name.upper()}',f'Goal: {goal} | Intensity: {intensity.title()}','\nGeneral guidance: stop for sharp pain, dizziness, or unusual symptoms.']
 for day,focus,exs in days:
  out += [f'\n{day} — {focus}','Warm-up: 5–10 minutes of easy movement.']+[f'• {e}: {vol} or 30–45 sec, rest 45–90 sec' for e in exs.split('; ')]+['Cooldown: 5–10 minutes of gentle movement and stretching.']
 return '\n'.join(out)
def demo_tip(goal): return f'For your {goal} goal, build meals around protein-rich foods, vegetables or fruit, adequate fluids, and minimally processed carbohydrate sources. Adjust portions to your energy needs rather than following a one-size-fits-all rule.'
class GeminiService:
 def __init__(self):
  self.s=get_settings(); self.client=genai.Client(api_key=self.s.gemini_api_key) if self.s.gemini_api_key else None
 @property
 def live(self): return self.client is not None
 def json(self,model,prompt,schema):
  r=self.client.models.generate_content(model=model,contents=prompt,config=types.GenerateContentConfig(response_mime_type='application/json',response_schema=schema,temperature=.4))
  try:return schema.model_validate_json(r.text)
  except ValidationError:return schema.model_validate(json.loads(r.text))
 def generate_workout(self,username,age,weight,goal,intensity):
  if not self.live:return demo_workout(goal,intensity,username)
  p=f'''Create a safe practical 7-day general fitness plan for {username}. Profile: age {age}, weight {weight} kg, goal {goal}, intensity {intensity}. Return exactly 7 days; each day needs focus, 5–10 minute warmup, 2–5 exercises with sets/reps or duration and rest, and cooldown. Include at least one recovery day. Do not diagnose or prescribe medical treatment.'''
  return self.fmt(self.json(self.s.workout_model,p,WorkoutPlan))
 def generate_nutrition_tip(self,goal,intensity):
  if not self.live:return demo_tip(goal)
  x=self.json(self.s.nutrition_model,f'Give one concise practical nutrition or recovery tip for a general fitness user. Goal: {goal}. Intensity: {intensity}. Avoid medical treatment claims, exact calorie prescriptions, or unsafe dieting.',NutritionTip);return f'{x.tip}\n\nWhy it helps: {x.why_it_helps}'
 def update_workout(self,original_plan,feedback,goal,intensity):
  if not self.live:return original_plan+f'\n\nUPDATED FROM FEEDBACK\n• {feedback}'
  p=f'''Revise this 7-day fitness plan according to feedback: {feedback}. Goal: {goal}; intensity: {intensity}. Keep exactly 7 days, preserve useful structure, and avoid medical diagnosis/treatment. Original plan:\n{original_plan}'''
  return self.fmt(self.json(self.s.workout_model,p,WorkoutPlan))
 @staticmethod
 def fmt(plan):
  o=[plan.title,'',plan.overview]
  for d in plan.days:
   o += [f'\n{d.day} — {d.focus}',f'Warm-up: {d.warmup}']+[f'• {e.name}: {e.sets_or_duration}; rest {e.rest}'+(f' — {e.notes}' if e.notes else '') for e in d.exercises]+[f'Cooldown: {d.cooldown}']
  return '\n'.join(o)
