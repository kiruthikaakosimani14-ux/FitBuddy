from typing import Literal
from pydantic import BaseModel,Field,field_validator
class UserInput(BaseModel):
 user_id:str=Field(min_length=2,max_length=80); username:str=Field(min_length=2,max_length=120); age:int=Field(ge=13,le=100); weight:float=Field(gt=20,le=500); goal:str=Field(min_length=2,max_length=200); intensity:Literal['low','medium','high']
 @field_validator('user_id','username','goal')
 @classmethod
 def clean(cls,v): return ' '.join(v.strip().split())
class FeedbackRequest(BaseModel): user_id:str=Field(min_length=2,max_length=80); feedback:str=Field(min_length=3,max_length=2000)
class GenerateResponse(BaseModel): user_id:str; username:str; goal:str; intensity:str; workout_plan:str; nutrition_tip:str
