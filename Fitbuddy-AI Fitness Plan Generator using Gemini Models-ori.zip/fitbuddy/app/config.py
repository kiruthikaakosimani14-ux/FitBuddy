from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
BASE_DIR=Path(__file__).resolve().parent.parent
DATA_DIR=BASE_DIR/'data'; DATA_DIR.mkdir(exist_ok=True)
class Settings(BaseSettings):
    app_name:str='FitBuddy'; debug:bool=True
    database_url:str=f"sqlite:///{(DATA_DIR/'fitbuddy.db').as_posix()}"
    gemini_api_key:str|None=None; workout_model:str='gemini-2.5-pro'; nutrition_model:str='gemini-2.5-flash'; admin_token:str|None=None
    model_config=SettingsConfigDict(env_file='.env',env_file_encoding='utf-8',case_sensitive=False,extra='ignore')
@lru_cache
def get_settings(): return Settings()
