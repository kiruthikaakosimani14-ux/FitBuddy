import os
os.environ['DATABASE_URL']='sqlite:///./data/test_fitbuddy.db';os.environ.pop('GEMINI_API_KEY',None)
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base,engine
Base.metadata.drop_all(bind=engine);Base.metadata.create_all(bind=engine)
client=TestClient(app)
def test_health(): assert client.get('/health').status_code==200
def test_home(): assert 'FitBuddy' in client.get('/').text
def test_generate():
 r=client.post('/api/generate-workout',json={'user_id':'T01','username':'Test User','age':25,'weight':70,'goal':'wellness','intensity':'medium'});assert r.status_code==200;assert '7-DAY' in r.json()['workout_plan']
def test_feedback():
 r=client.post('/api/submit-feedback',json={'user_id':'T01','feedback':'Add more cardio'});assert r.status_code==200;assert 'UPDATED FROM FEEDBACK' in r.json()['updated_plan']
